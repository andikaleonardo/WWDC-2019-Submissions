import UIKit
extension String {
    public func shaHash() -> String {
        return self.sha256()
    }
}
//  Inspired by anders.com/blockchain
//  bitcoin.org
