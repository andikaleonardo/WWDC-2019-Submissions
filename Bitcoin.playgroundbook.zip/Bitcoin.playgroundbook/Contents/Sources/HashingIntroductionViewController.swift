import UIKit
import PlaygroundSupport

public class HashingIntroductionViewController : UIViewController, PlaygroundLiveViewMessageHandler {
    
    public let originalText = UILabel()
    public let imageView = UIImageView()
    public let hashLabel = UILabel()
    
    public override func viewDidLoad() {
        view.backgroundColor = .white
        
        
        originalText.translatesAutoresizingMaskIntoConstraints = false
        originalText.text = "Apple Developer Academy Indonesia."
        originalText.textColor = .black
        originalText.numberOfLines = -1
        originalText.font = UIFont.systemFont(ofSize: 22)
        originalText.textAlignment = .center
        
        imageView.image = UIImage(named: "arrow")
        imageView.contentMode = .scaleAspectFit
        
        
        hashLabel.translatesAutoresizingMaskIntoConstraints = false
        hashLabel.text = "Run My Code Please"
        hashLabel.textColor = .black
        hashLabel.numberOfLines = -1
        hashLabel.font = UIFont(name: "Menlo", size: 22)
        originalText.textAlignment = .center
        
        let stackView = UIStackView()
        stackView.axis = .vertical;
        stackView.distribution = .equalSpacing;
        stackView.alignment = .center;
        stackView.spacing = 30;
        stackView.addArrangedSubview(originalText)
        stackView.addArrangedSubview(imageView)
        stackView.addArrangedSubview(hashLabel)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)
        
        
        let widthConstraint = NSLayoutConstraint(item: originalText, attribute: .width, relatedBy: .equal,
                                                 toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 250)
        let widthConstraintImage = NSLayoutConstraint(item: imageView, attribute: .width, relatedBy: .equal,
                                                          toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 250)
        let widthConstraintHashLabel = NSLayoutConstraint(item: hashLabel, attribute: .width, relatedBy: .equal,
                                                          toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 250)
        
        
        let xConstraint = NSLayoutConstraint(item: stackView, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1, constant: 0)
        
        let yConstraint = NSLayoutConstraint(item: stackView, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1, constant: 0)
        
        NSLayoutConstraint.activate([widthConstraint, xConstraint, yConstraint, widthConstraintHashLabel, widthConstraintImage])
    }
    
    public func receive(_ message: PlaygroundValue) {
        
        guard case let .dictionary(dict) = message else {return}
        if case let .string(string)? = dict["textString"] {
            originalText.text = string
        }
        if case let .string(string)? = dict["hashString"] {
            hashLabel.text = string
        }
    }
}
//  Inspired by anders.com/blockchain
//  bitcoin.org
