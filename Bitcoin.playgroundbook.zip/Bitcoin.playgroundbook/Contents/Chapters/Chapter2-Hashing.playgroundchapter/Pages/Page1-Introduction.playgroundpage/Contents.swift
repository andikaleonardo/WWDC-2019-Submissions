//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code
//: # BlockChain - the Key behind Bitcoin.
//: Blockchain is a database  that is shared across a network of computers. Once a record has been added to the chain it is very difficult to change. To ensure all the copies of the database are the same, the network  makes constant checks. Blockchains have been used to underpin cyber-currencies like bitcoin, but many other possible uses  are emerging.
//: # Secure Hash Algorithm
//: `SHA256` is the hashing algorithm that is currently used by the Bitcoin blockchain. You can generate the hash in this playground using the `.shaHash()` function on objects, such as a `String`.
//: Generates a random 256-bit private key (64 hex characters)
//: It is a unique identification for digital assets, such as pictures or programing objects such as `Strings` and `Colors`. It is easy to generate a hash for a given object, but going back from the hash to the object is computationally expensive, as of today.

let string = /*#-editable-code*/"Apple Developer Academy Indonesia"/*#-end-editable-code*/
let hash = string.shaHash()

//: Now, run your program and see the result on the right side.

//#-hidden-code
if let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy {
    let dict = PlaygroundValue.dictionary([
        "textString": PlaygroundValue.string(string),
        "hashString": PlaygroundValue.string(hash)])
    proxy.send(dict)
}
//#-end-hidden-code
//: [Next Page](@next)


//  Created by Andika on 1/2/19.
//  Copyright © 2019 Andika. All rights reserved.
//  Inspired by anders.com/blockchain
//  bitcoin.org
