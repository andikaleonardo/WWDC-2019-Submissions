//: # Hash
//: Hash is an important core concept of blockchains. A hash function is any function that can be used to map data of arbitrary size onto data of a fixed size. The values returned by a hash function are called hash values, hash codes, digests, or simply hashes. Hash functions are often used in combination with a hash table, a common data structure used in computer software for rapid data lookup. Hash functions accelerate table or database lookup by detecting duplicated records in a large file.

"Andika".shaHash() == "Andika".shaHash()

//: Changing one object slightly will result in a completely different hash.
/*#-editable-code*/"Andika"/*#-end-editable-code*/.shaHash() == /*#-editable-code*/"Andika"/*#-end-editable-code*/.shaHash()

//:# sha256 Concluding Hash
//: The previous page showed that the `.shaHash()` function generates a hexadecimal string that is unique for every unique object – and equal objects create equal hashes. When executing your code, the result of each line is shown on the right side next to it (tap on it to see more).

//: [Next Page](@next)

//  Created by Andika on 1/2/19.
//  Copyright © 2019 Andika. All rights reserved.
//  Inspired by anders.com/blockchain
//  bitcoin.org
