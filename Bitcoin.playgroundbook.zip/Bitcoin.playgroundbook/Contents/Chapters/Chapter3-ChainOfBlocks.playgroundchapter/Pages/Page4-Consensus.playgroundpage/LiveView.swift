//: A UIKit based Playground for presenting user interface

import UIKit
import PlaygroundSupport

// Present the view controller in the Live View window
let block1 = ProxyBlock(value: "A paid 10 Bitcoin to B.", previousBlock: nil, previousHash: nil, isChainValid: true)
let block2 = ProxyBlock(value: "B paid 9 Bitcoin to C.", previousBlock: block1, previousHash: nil, isChainValid: true)
let block3 = ProxyBlock(value: "C paid 8 Bitcoin to D.", previousBlock: block2, previousHash: nil, isChainValid: true)
let block4 = ProxyBlock(value: "D paid 7 Bitcoin to E.", previousBlock: block3, previousHash: nil, isChainValid: true)
let block5 = ProxyBlock(value: "E paid 6 Bitcoin to F.", previousBlock: block4, previousHash: nil, isChainValid: true)
let block6 = ProxyBlock(value: "F paid 5 Bitcoin to G.", previousBlock: block5, previousHash: nil, isChainValid: true)
let block7 = ProxyBlock(value: "G paid 4 Bitcoin to H.", previousBlock: block6, previousHash: nil, isChainValid: true)
let block8 = ProxyBlock(value: "H paid 3 Bitcoin to I.", previousBlock: block7, previousHash: nil, isChainValid: true)
let block9 = ProxyBlock(value: "I paid 2 Bitcoin to J.", previousBlock: block8, previousHash: nil, isChainValid: true)
let block10 = ProxyBlock(value: "J paid 1 Bitcoin to K.", previousBlock: block9, previousHash: nil, isChainValid: true)
PlaygroundPage.current.liveView = BlockChainViewController(defaultProxyBlockChain: block10)
PlaygroundPage.current.needsIndefiniteExecution = true
