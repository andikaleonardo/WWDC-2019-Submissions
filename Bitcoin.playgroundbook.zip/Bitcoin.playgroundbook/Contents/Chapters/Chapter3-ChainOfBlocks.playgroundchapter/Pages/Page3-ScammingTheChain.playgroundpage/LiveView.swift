//: A UIKit based Playground for presenting user interface

import UIKit
import PlaygroundSupport

// Present the view controller in the Live View window
let block1 = ProxyBlock(value: "Andika paid 3 Bitcoin to Nadya.", previousBlock: nil, previousHash: nil, isChainValid: true)
let block2 = ProxyBlock(value: "Nadya paid 1 Bitcoin to Michelle.", previousBlock: block1, previousHash: nil, isChainValid: true)
let block3 = ProxyBlock(value: "Michelle paid 99999 Bitcoin to Leonardo.", previousBlock: block2, previousHash: nil, isChainValid: false)
let block4 = ProxyBlock(value: "Leonardo paid 1 Bitcoin to Binus.", previousBlock: block3, previousHash: nil, isChainValid: false)
PlaygroundPage.current.liveView = BlockChainViewController(defaultProxyBlockChain: block4)
PlaygroundPage.current.needsIndefiniteExecution = true
