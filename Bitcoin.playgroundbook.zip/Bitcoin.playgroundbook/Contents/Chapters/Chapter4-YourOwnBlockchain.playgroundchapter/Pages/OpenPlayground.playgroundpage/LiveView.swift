//: A UIKit based Playground for presenting user interface

import UIKit
import PlaygroundSupport

// Present the view controller in the Live View window
let block1 = ProxyBlock(value: "Tim Cook paid 3 Bitcoin to Angela Ahrendts.", previousBlock: nil, previousHash: nil, isChainValid: true)
let block2 = ProxyBlock(value: "Angela Ahrendts paid 1 Bitcoin to Craig Federighi.", previousBlock: block1, previousHash: nil, isChainValid: true)
let block3 = ProxyBlock(value: "Craig Federighi paid 2 Bitcoin to Jonathan Ive.", previousBlock: block2, previousHash: nil, isChainValid: true)
PlaygroundPage.current.liveView = BlockChainViewController(defaultProxyBlockChain: block3)
PlaygroundPage.current.needsIndefiniteExecution = true
